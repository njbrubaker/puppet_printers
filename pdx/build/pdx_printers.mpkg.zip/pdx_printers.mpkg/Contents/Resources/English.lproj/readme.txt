This package will install and configure the Portland office printers. Please note that it will not configure the printer Barkley, as that printer is private to the Human Resources department. If you would like to install Barkley, please visit the Help Desk or file a Help ticket in Jira. 

To begin the installation, click Continue.
